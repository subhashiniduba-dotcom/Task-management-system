package com.tms.ui;

import com.tms.model.Task;
import com.tms.model.User;
import com.tms.service.TaskService;
import com.tms.service.UserService;
import com.tms.util.DateUtil;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

/**
 * ConsoleUI — interactive text-based user interface.
 * Demonstrates: Separation of Concerns (UI layer separate from business logic).
 */
public class ConsoleUI {

    private final TaskService taskService;
    private final UserService userService;
    private final Scanner     scanner;

    private static final String LINE = "─".repeat(60);
    private static final String DLINE = "═".repeat(60);

    public ConsoleUI(TaskService taskService, UserService userService) {
        this.taskService = taskService;
        this.userService = userService;
        this.scanner     = new Scanner(System.in);
    }

    public void start() {
        printBanner();
        boolean running = true;
        while (running) {
            printMainMenu();
            String choice = scanner.nextLine().trim();
            switch (choice) {
                case "1":  handleCreateTask();    break;
                case "2":  handleViewAllTasks();  break;
                case "3":  handleUpdateTask();    break;
                case "4":  handleDeleteTask();    break;
                case "5":  handleSearchTasks();   break;
                case "6":  handleFilterTasks();   break;
                case "7":  handleOverdueTasks();  break;
                case "8":  handleStatistics();    break;
                case "9":  handleUserMenu();      break;
                case "0":  running = false; print("\n👋 Goodbye!\n"); break;
                default:   print("❌ Invalid option. Try again.\n");
            }
        }
    }

    // ── Main Menu ─────────────────────────────
    private void printMainMenu() {
        System.out.println("\n" + LINE);
        System.out.println("  TASK MANAGEMENT SYSTEM — Main Menu");
        System.out.println(LINE);
        System.out.println("  1. ➕ Create Task          5. 🔍 Search Tasks");
        System.out.println("  2. 📋 View All Tasks        6. 🔽 Filter Tasks");
        System.out.println("  3. ✏️  Update Task           7. ⚠️  Overdue Tasks");
        System.out.println("  4. 🗑️  Delete Task           8. 📊 Statistics");
        System.out.println("  9. 👥 User Management       0. 🚪 Exit");
        System.out.println(LINE);
        System.out.print("  Enter choice: ");
    }

    // ── Create Task ───────────────────────────
    private void handleCreateTask() {
        System.out.println("\n" + LINE);
        System.out.println("  ➕ CREATE NEW TASK");
        System.out.println(LINE);

        System.out.print("  Title*        : ");
        String title = scanner.nextLine().trim();
        if (title.isEmpty()) { print("❌ Title cannot be empty."); return; }

        System.out.print("  Description   : ");
        String desc = scanner.nextLine().trim();

        System.out.print("  Priority [LOW/MEDIUM/HIGH/CRITICAL] (default MEDIUM): ");
        Task.Priority priority = parsePriority(scanner.nextLine().trim());

        System.out.print("  Assigned To   : ");
        String assignee = scanner.nextLine().trim();

        System.out.print("  Category      : ");
        String category = scanner.nextLine().trim();

        System.out.print("  Due Date (dd-MM-yyyy, blank to skip): ");
        LocalDate dueDate = parseDate(scanner.nextLine().trim());

        try {
            Task task = taskService.createTask(title, desc, priority,
                assignee.isEmpty() ? "Unassigned" : assignee,
                category.isEmpty() ? "General"    : category,
                dueDate);
            System.out.println("\n  ✅ Task created successfully!");
            printTaskDetail(task);
        } catch (Exception e) {
            print("❌ " + e.getMessage());
        }
    }

    // ── View All Tasks ────────────────────────
    private void handleViewAllTasks() {
        List<Task> tasks = taskService.getAllTasks();
        System.out.println("\n" + LINE);
        System.out.printf("  📋 ALL TASKS (%d)%n", tasks.size());
        System.out.println(LINE);
        if (tasks.isEmpty()) { print("  No tasks found."); return; }
        printTaskTable(tasks);
    }

    // ── Update Task ───────────────────────────
    private void handleUpdateTask() {
        System.out.println("\n" + LINE);
        System.out.println("  ✏️  UPDATE TASK");
        System.out.println(LINE);
        System.out.print("  Enter Task ID: ");
        String id = scanner.nextLine().trim().toUpperCase();

        try {
            Task task = taskService.getById(id);
            printTaskDetail(task);

            System.out.println("\n  What to update?");
            System.out.println("  1. Title    2. Status    3. Priority");
            System.out.println("  4. Progress 5. Assignee  6. Mark Complete");
            System.out.print("  Choice: ");
            String sub = scanner.nextLine().trim();

            switch (sub) {
                case "1":
                    System.out.print("  New title: ");
                    task = taskService.updateTitle(id, scanner.nextLine());
                    break;
                case "2":
                    System.out.print("  New status [TODO/IN_PROGRESS/ON_HOLD/COMPLETED/CANCELLED]: ");
                    Task.Status status = parseStatus(scanner.nextLine().trim());
                    task = taskService.updateStatus(id, status);
                    break;
                case "3":
                    System.out.print("  New priority [LOW/MEDIUM/HIGH/CRITICAL]: ");
                    task = taskService.updatePriority(id, parsePriority(scanner.nextLine().trim()));
                    break;
                case "4":
                    System.out.print("  Progress (0-100): ");
                    task = taskService.updateProgress(id, parseInt(scanner.nextLine().trim(), 0));
                    break;
                case "5":
                    System.out.print("  Assign to: ");
                    task = taskService.assignTask(id, scanner.nextLine().trim());
                    break;
                case "6":
                    task = taskService.markComplete(id);
                    break;
                default:
                    print("❌ Invalid choice.");
                    return;
            }
            System.out.println("  ✅ Updated successfully!");
            printTaskDetail(task);

        } catch (Exception e) {
            print("❌ " + e.getMessage());
        }
    }

    // ── Delete Task ───────────────────────────
    private void handleDeleteTask() {
        System.out.print("\n  Enter Task ID to delete: ");
        String id = scanner.nextLine().trim().toUpperCase();
        System.out.print("  Confirm delete? [yes/no]: ");
        if (!"yes".equalsIgnoreCase(scanner.nextLine().trim())) { print("  Cancelled."); return; }
        try {
            taskService.deleteTask(id);
            print("  ✅ Task " + id + " deleted.");
        } catch (Exception e) {
            print("  ❌ " + e.getMessage());
        }
    }

    // ── Search ────────────────────────────────
    private void handleSearchTasks() {
        System.out.print("\n  🔍 Search keyword: ");
        String kw = scanner.nextLine().trim();
        List<Task> results = taskService.searchByTitle(kw);
        System.out.printf("%n  Found %d result(s) for \"%s\"%n", results.size(), kw);
        if (!results.isEmpty()) printTaskTable(results);
    }

    // ── Filter ────────────────────────────────
    private void handleFilterTasks() {
        System.out.println("\n  Filter by: 1.Status  2.Priority  3.Assignee");
        System.out.print("  Choice: ");
        String choice = scanner.nextLine().trim();
        List<Task> results;
        switch (choice) {
            case "1":
                System.out.print("  Status [TODO/IN_PROGRESS/ON_HOLD/COMPLETED/CANCELLED]: ");
                results = taskService.getByStatus(parseStatus(scanner.nextLine().trim()));
                break;
            case "2":
                System.out.print("  Priority [LOW/MEDIUM/HIGH/CRITICAL]: ");
                results = taskService.getByPriority(parsePriority(scanner.nextLine().trim()));
                break;
            case "3":
                System.out.print("  Assignee name: ");
                results = taskService.getByAssignee(scanner.nextLine().trim());
                break;
            default:
                print("❌ Invalid choice."); return;
        }
        System.out.printf("%n  Found %d task(s)%n", results.size());
        if (!results.isEmpty()) printTaskTable(results);
    }

    // ── Overdue ───────────────────────────────
    private void handleOverdueTasks() {
        List<Task> overdue = taskService.getOverdueTasks();
        System.out.println("\n" + LINE);
        System.out.printf("  ⚠️  OVERDUE TASKS (%d)%n", overdue.size());
        System.out.println(LINE);
        if (overdue.isEmpty()) { print("  No overdue tasks. Great job! ✅"); return; }
        printTaskTable(overdue);
    }

    // ── Statistics ────────────────────────────
    private void handleStatistics() {
        Map<String, Object> stats = taskService.getStatistics();
        System.out.println("\n" + DLINE);
        System.out.println("  📊 TASK STATISTICS");
        System.out.println(DLINE);
        stats.forEach((k, v) -> System.out.printf("  %-20s : %s%n", k, v));
        System.out.println(DLINE);
    }

    // ── User Menu ─────────────────────────────
    private void handleUserMenu() {
        System.out.println("\n  👥 User: 1.Create  2.List  3.Filter by Role");
        System.out.print("  Choice: ");
        String choice = scanner.nextLine().trim();
        switch (choice) {
            case "1":
                System.out.print("  Name: "); String name = scanner.nextLine();
                System.out.print("  Email: "); String email = scanner.nextLine();
                System.out.print("  Role [ADMIN/MANAGER/DEVELOPER/TESTER/VIEWER]: ");
                User.Role role = parseRole(scanner.nextLine().trim());
                try {
                    User u = userService.createUser(name, email, role);
                    System.out.println("  ✅ User created: " + u);
                } catch (Exception e) { print("  ❌ " + e.getMessage()); }
                break;
            case "2":
                userService.getAllUsers().forEach(u -> System.out.println("  " + u));
                break;
            case "3":
                System.out.print("  Role: ");
                userService.getUsersByRole(parseRole(scanner.nextLine().trim()))
                    .forEach(u -> System.out.println("  " + u));
                break;
            default: print("❌ Invalid.");
        }
    }

    // ── Rendering Helpers ─────────────────────
    private void printTaskTable(List<Task> tasks) {
        System.out.printf("%n  %-8s %-28s %-9s %-12s %4s%n",
            "ID", "Title", "Priority", "Status", "%");
        System.out.println("  " + "─".repeat(66));
        tasks.forEach(t -> System.out.printf("  %-8s %-28s %-9s %-12s %3d%%%s%n",
            t.getId(),
            truncate(t.getTitle(), 27),
            t.getPriority(),
            t.getStatus(),
            t.getCompletionPercent(),
            t.isOverdue() ? " ⚠️" : ""));
    }

    private void printTaskDetail(Task t) {
        System.out.println("\n  " + LINE);
        System.out.printf("  ID          : %s%n", t.getId());
        System.out.printf("  Title       : %s%n", t.getTitle());
        System.out.printf("  Description : %s%n", t.getDescription().isEmpty() ? "—" : t.getDescription());
        System.out.printf("  Priority    : %s%n", t.getPriority());
        System.out.printf("  Status      : %s%n", t.getStatus());
        System.out.printf("  Assigned To : %s%n", t.getAssignedTo());
        System.out.printf("  Category    : %s%n", t.getCategory());
        System.out.printf("  Progress    : %d%%%n", t.getCompletionPercent());
        System.out.printf("  Due Date    : %s%n", DateUtil.dueDateStatus(t.getDueDate()));
        System.out.printf("  Created At  : %s%n", DateUtil.formatDateTime(t.getCreatedAt()));
        System.out.println("  " + LINE);
    }

    private void printBanner() {
        System.out.println("\n" + DLINE);
        System.out.println("  ████████╗███╗   ███╗███████╗");
        System.out.println("     ██╔══╝████╗ ████║██╔════╝");
        System.out.println("     ██║   ██╔████╔██║███████╗");
        System.out.println("     ██║   ██║╚██╔╝██║╚════██║");
        System.out.println("     ██║   ██║ ╚═╝ ██║███████║");
        System.out.println("     ╚═╝   ╚═╝     ╚═╝╚══════╝");
        System.out.println("  Task Management System — OOP Edition");
        System.out.println(DLINE);
    }

    // ── Parse Helpers ─────────────────────────
    private Task.Priority parsePriority(String s) {
        try { return Task.Priority.valueOf(s.toUpperCase()); } catch (Exception e) { return Task.Priority.MEDIUM; }
    }

    private Task.Status parseStatus(String s) {
        try { return Task.Status.valueOf(s.toUpperCase()); } catch (Exception e) { return Task.Status.TODO; }
    }

    private User.Role parseRole(String s) {
        try { return User.Role.valueOf(s.toUpperCase()); } catch (Exception e) { return User.Role.DEVELOPER; }
    }

    private LocalDate parseDate(String s) {
        if (s == null || s.isEmpty()) return null;
        try { return LocalDate.parse(s, DateUtil.DATE_FMT); } catch (Exception e) { return null; }
    }

    private int parseInt(String s, int def) {
        try { return Integer.parseInt(s); } catch (Exception e) { return def; }
    }

    private String truncate(String s, int max) {
        return s.length() <= max ? s : s.substring(0, max - 1) + "…";
    }

    private void print(String msg) { System.out.println("  " + msg); }
}
