package com.tms.util;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

/**
 * DateUtil — date formatting and calculation helpers.
 * Demonstrates: Static utility pattern, Java Time API.
 */
public final class DateUtil {

    private DateUtil() {}

    public static final DateTimeFormatter DATE_FMT      = DateTimeFormatter.ofPattern("dd-MM-yyyy");
    public static final DateTimeFormatter DATETIME_FMT  = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm");

    public static String formatDate(LocalDate date) {
        return date == null ? "—" : date.format(DATE_FMT);
    }

    public static String formatDateTime(LocalDateTime dt) {
        return dt == null ? "—" : dt.format(DATETIME_FMT);
    }

    public static long daysUntilDue(LocalDate dueDate) {
        if (dueDate == null) return Long.MAX_VALUE;
        return ChronoUnit.DAYS.between(LocalDate.now(), dueDate);
    }

    public static String dueDateStatus(LocalDate dueDate) {
        if (dueDate == null) return "No deadline";
        long days = daysUntilDue(dueDate);
        if (days < 0)  return "OVERDUE by " + Math.abs(days) + " days";
        if (days == 0) return "Due TODAY";
        if (days == 1) return "Due TOMORROW";
        return "Due in " + days + " days";
    }
}
