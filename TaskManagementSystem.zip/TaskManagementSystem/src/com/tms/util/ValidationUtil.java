package com.tms.util;

import com.tms.exception.ValidationException;

/**
 * ValidationUtil — static helper methods for input validation.
 * Demonstrates: Utility class pattern, defensive programming.
 */
public final class ValidationUtil {

    private ValidationUtil() {}  // Prevent instantiation

    public static void requireNonNull(Object value, String fieldName) {
        if (value == null)
            throw new ValidationException(fieldName + " must not be null.");
    }

    public static void requireNonEmpty(String value, String fieldName) {
        if (value == null || value.trim().isEmpty())
            throw new ValidationException(fieldName + " must not be empty.");
    }

    public static void requireRange(int value, int min, int max, String fieldName) {
        if (value < min || value > max)
            throw new ValidationException(
                fieldName + " must be between " + min + " and " + max + ". Got: " + value);
    }

    public static void requireValidEmail(String email) {
        if (email == null || !email.matches("^[\\w._%+\\-]+@[\\w.\\-]+\\.[a-zA-Z]{2,}$"))
            throw new ValidationException("Invalid email address: " + email);
    }

    public static void requirePositive(int value, String fieldName) {
        if (value <= 0)
            throw new ValidationException(fieldName + " must be positive. Got: " + value);
    }
}
