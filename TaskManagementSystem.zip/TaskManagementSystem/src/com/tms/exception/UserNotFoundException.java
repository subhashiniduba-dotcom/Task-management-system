package com.tms.exception;

/** Thrown when a requested User does not exist. */
public class UserNotFoundException extends RuntimeException {
    public UserNotFoundException(String id) {
        super("User not found with ID: " + id);
    }
}
