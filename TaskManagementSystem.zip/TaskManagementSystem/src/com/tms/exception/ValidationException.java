package com.tms.exception;

/** Thrown when input data fails validation rules. */
public class ValidationException extends RuntimeException {
    public ValidationException(String message) {
        super("Validation failed: " + message);
    }
}
