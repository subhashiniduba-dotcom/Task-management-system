package com.tms.exception;

/** Thrown when a requested Task does not exist. */
public class TaskNotFoundException extends RuntimeException {
    public TaskNotFoundException(String id) {
        super("Task not found with ID: " + id);
    }
}
