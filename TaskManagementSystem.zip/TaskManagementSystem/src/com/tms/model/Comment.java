package com.tms.model;

import java.time.LocalDateTime;
import java.util.UUID;

/**
 * Comment — a note attached to a Task.
 * Demonstrates: Immutability (all fields final after creation).
 */
public class Comment {

    private final String        id;
    private final String        taskId;
    private final String        authorId;
    private final String        authorName;
    private final String        content;
    private final LocalDateTime createdAt;

    public Comment(String taskId, String authorId, String authorName, String content) {
        this.id         = UUID.randomUUID().toString().substring(0, 6).toUpperCase();
        this.taskId     = taskId;
        this.authorId   = authorId;
        this.authorName = authorName;
        this.content    = content;
        this.createdAt  = LocalDateTime.now();
    }

    public String        getId()         { return id; }
    public String        getTaskId()     { return taskId; }
    public String        getAuthorId()   { return authorId; }
    public String        getAuthorName() { return authorName; }
    public String        getContent()    { return content; }
    public LocalDateTime getCreatedAt()  { return createdAt; }

    @Override
    public String toString() {
        return String.format("[%s] %s (%s): %s",
            createdAt.toLocalDate(), authorName, id, content);
    }
}
