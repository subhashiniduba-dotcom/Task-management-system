package com.tms.model;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.UUID;

/**
 * Task — core domain entity.
 * Demonstrates: Encapsulation, Immutable ID, Builder Pattern.
 */
public class Task {

    // ── Enums ────────────────────────────────
    public enum Priority { LOW, MEDIUM, HIGH, CRITICAL }
    public enum Status   { TODO, IN_PROGRESS, ON_HOLD, COMPLETED, CANCELLED }

    // ── Fields ───────────────────────────────
    private final String        id;
    private       String        title;
    private       String        description;
    private       Priority      priority;
    private       Status        status;
    private       String        assignedTo;
    private       String        category;
    private       LocalDate     dueDate;
    private final LocalDateTime createdAt;
    private       LocalDateTime updatedAt;
    private       int           completionPercent;  // 0–100

    // ── Private Constructor (Builder only) ───
    private Task(Builder b) {
        this.id                = UUID.randomUUID().toString().substring(0, 8).toUpperCase();
        this.title             = b.title;
        this.description       = b.description;
        this.priority          = b.priority;
        this.status            = Status.TODO;
        this.assignedTo        = b.assignedTo;
        this.category          = b.category;
        this.dueDate           = b.dueDate;
        this.createdAt         = LocalDateTime.now();
        this.updatedAt         = LocalDateTime.now();
        this.completionPercent = 0;
    }

    // ── Builder ──────────────────────────────
    public static class Builder {
        private final String title;
        private String    description = "";
        private Priority  priority    = Priority.MEDIUM;
        private String    assignedTo  = "Unassigned";
        private String    category    = "General";
        private LocalDate dueDate     = null;

        public Builder(String title)             { this.title       = title; }
        public Builder description(String d)     { this.description = d; return this; }
        public Builder priority(Priority p)      { this.priority    = p; return this; }
        public Builder assignedTo(String a)      { this.assignedTo  = a; return this; }
        public Builder category(String c)        { this.category    = c; return this; }
        public Builder dueDate(LocalDate d)      { this.dueDate     = d; return this; }
        public Task    build()                   { return new Task(this); }
    }

    // ── Business Logic ───────────────────────
    public boolean isOverdue() {
        return dueDate != null
            && LocalDate.now().isAfter(dueDate)
            && status != Status.COMPLETED
            && status != Status.CANCELLED;
    }

    public boolean isCompleted() {
        return status == Status.COMPLETED;
    }

    public void markComplete() {
        this.status            = Status.COMPLETED;
        this.completionPercent = 100;
        this.updatedAt         = LocalDateTime.now();
    }

    public void updateProgress(int percent) {
        if (percent < 0 || percent > 100)
            throw new IllegalArgumentException("Progress must be 0–100, got: " + percent);
        this.completionPercent = percent;
        if (percent == 100)      this.status = Status.COMPLETED;
        else if (percent > 0)    this.status = Status.IN_PROGRESS;
        this.updatedAt = LocalDateTime.now();
    }

    // ── Getters ──────────────────────────────
    public String        getId()                  { return id; }
    public String        getTitle()               { return title; }
    public String        getDescription()         { return description; }
    public Priority      getPriority()            { return priority; }
    public Status        getStatus()              { return status; }
    public String        getAssignedTo()          { return assignedTo; }
    public String        getCategory()            { return category; }
    public LocalDate     getDueDate()             { return dueDate; }
    public LocalDateTime getCreatedAt()           { return createdAt; }
    public LocalDateTime getUpdatedAt()           { return updatedAt; }
    public int           getCompletionPercent()   { return completionPercent; }

    // ── Setters (with updatedAt tracking) ────
    public void setTitle(String title)            { this.title       = title;       this.updatedAt = LocalDateTime.now(); }
    public void setDescription(String desc)       { this.description = desc;        this.updatedAt = LocalDateTime.now(); }
    public void setPriority(Priority priority)    { this.priority    = priority;    this.updatedAt = LocalDateTime.now(); }
    public void setStatus(Status status)          { this.status      = status;      this.updatedAt = LocalDateTime.now(); }
    public void setAssignedTo(String assignedTo)  { this.assignedTo  = assignedTo;  this.updatedAt = LocalDateTime.now(); }
    public void setCategory(String category)      { this.category    = category;    this.updatedAt = LocalDateTime.now(); }
    public void setDueDate(LocalDate dueDate)     { this.dueDate     = dueDate;     this.updatedAt = LocalDateTime.now(); }

    @Override
    public String toString() {
        return String.format("[%s] %-30s | %-8s | %-11s | %3d%% | %s",
            id, title, priority, status, completionPercent,
            dueDate != null ? dueDate.toString() : "No due date");
    }
}
