package com.tms.model;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * User — represents a system user who can be assigned tasks.
 * Demonstrates: Encapsulation, defensive copying of collections.
 */
public class User {

    public enum Role { ADMIN, MANAGER, DEVELOPER, TESTER, VIEWER }

    private final String        id;
    private       String        name;
    private       String        email;
    private       Role          role;
    private       boolean       active;
    private final LocalDateTime createdAt;
    private final List<String>  taskIds;   // IDs of assigned tasks

    public User(String id, String name, String email, Role role) {
        this.id        = id;
        this.name      = name;
        this.email     = email;
        this.role      = role;
        this.active    = true;
        this.createdAt = LocalDateTime.now();
        this.taskIds   = new ArrayList<>();
    }

    public void assignTask(String taskId)   { if (!taskIds.contains(taskId)) taskIds.add(taskId); }
    public void unassignTask(String taskId) { taskIds.remove(taskId); }
    public int  getTaskCount()              { return taskIds.size(); }

    // ── Getters ──────────────────────────────
    public String        getId()        { return id; }
    public String        getName()      { return name; }
    public String        getEmail()     { return email; }
    public Role          getRole()      { return role; }
    public boolean       isActive()     { return active; }
    public LocalDateTime getCreatedAt() { return createdAt; }

    /** Returns an unmodifiable view — defensive copy. */
    public List<String>  getTaskIds()   { return Collections.unmodifiableList(taskIds); }

    // ── Setters ───────────────────────────────
    public void setName(String name)    { this.name   = name; }
    public void setEmail(String email)  { this.email  = email; }
    public void setRole(Role role)      { this.role   = role; }
    public void setActive(boolean a)    { this.active = a; }

    @Override
    public String toString() {
        return String.format("User{id='%s', name='%s', role=%s, tasks=%d}", id, name, role, taskIds.size());
    }
}
