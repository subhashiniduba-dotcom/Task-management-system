package com.tms.repository;

import com.tms.model.Task;
import java.util.List;
import java.util.Optional;

/**
 * TaskRepository — interface defining the data access contract.
 * Demonstrates: Interface Segregation, Dependency Inversion (SOLID).
 * Swap implementations (InMemory ↔ Database) without changing service code.
 */
public interface TaskRepository {

    void           save(Task task);
    Optional<Task> findById(String id);
    List<Task>     findAll();
    List<Task>     findByStatus(Task.Status status);
    List<Task>     findByPriority(Task.Priority priority);
    List<Task>     findByAssignee(String assignedTo);
    List<Task>     findByCategory(String category);
    boolean        deleteById(String id);
    int            count();
    boolean        existsById(String id);
}
