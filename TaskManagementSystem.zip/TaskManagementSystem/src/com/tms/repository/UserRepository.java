package com.tms.repository;

import com.tms.model.User;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

/**
 * UserRepository — interface + in-memory implementation for User data access.
 */
public interface UserRepository {

    void           save(User user);
    Optional<User> findById(String id);
    Optional<User> findByEmail(String email);
    List<User>     findAll();
    List<User>     findByRole(User.Role role);
    boolean        deleteById(String id);
    boolean        existsById(String id);
}
