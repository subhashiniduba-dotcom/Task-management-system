package com.tms.repository;

import com.tms.model.Task;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

/**
 * InMemoryTaskRepository — stores tasks in a ConcurrentHashMap.
 * Demonstrates: Concrete implementation of interface, Stream API, thread safety.
 * Replace with DatabaseTaskRepository for persistent storage.
 */
public class InMemoryTaskRepository implements TaskRepository {

    private final Map<String, Task> store = new ConcurrentHashMap<>();

    @Override
    public void save(Task task) {
        store.put(task.getId(), task);
    }

    @Override
    public Optional<Task> findById(String id) {
        return Optional.ofNullable(store.get(id));
    }

    @Override
    public List<Task> findAll() {
        return new ArrayList<>(store.values());
    }

    @Override
    public List<Task> findByStatus(Task.Status status) {
        return store.values().stream()
            .filter(t -> t.getStatus() == status)
            .collect(Collectors.toList());
    }

    @Override
    public List<Task> findByPriority(Task.Priority priority) {
        return store.values().stream()
            .filter(t -> t.getPriority() == priority)
            .collect(Collectors.toList());
    }

    @Override
    public List<Task> findByAssignee(String assignedTo) {
        return store.values().stream()
            .filter(t -> t.getAssignedTo().equalsIgnoreCase(assignedTo))
            .collect(Collectors.toList());
    }

    @Override
    public List<Task> findByCategory(String category) {
        return store.values().stream()
            .filter(t -> t.getCategory().equalsIgnoreCase(category))
            .collect(Collectors.toList());
    }

    @Override
    public boolean deleteById(String id) {
        return store.remove(id) != null;
    }

    @Override
    public int count() {
        return store.size();
    }

    @Override
    public boolean existsById(String id) {
        return store.containsKey(id);
    }
}
