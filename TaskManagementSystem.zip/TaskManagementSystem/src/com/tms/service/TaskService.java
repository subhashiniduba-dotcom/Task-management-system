package com.tms.service;

import com.tms.exception.TaskNotFoundException;
import com.tms.model.Comment;
import com.tms.model.Task;
import com.tms.repository.TaskRepository;
import com.tms.util.ValidationUtil;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

/**
 * TaskService — business logic layer for Task operations.
 * Demonstrates: Single Responsibility, Dependency Injection,
 *               Open/Closed (extend via TaskRepository), SOLID.
 */
public class TaskService {

    private final TaskRepository taskRepo;
    private final Map<String, List<Comment>> commentsMap = new HashMap<>();

    public TaskService(TaskRepository taskRepo) {
        this.taskRepo = taskRepo;
    }

    // ── CREATE ────────────────────────────────
    public Task createTask(String title, String description,
                           Task.Priority priority, String assignedTo,
                           String category, LocalDate dueDate) {
        ValidationUtil.requireNonEmpty(title, "Title");

        Task task = new Task.Builder(title.trim())
            .description(description != null ? description : "")
            .priority(priority != null ? priority : Task.Priority.MEDIUM)
            .assignedTo(assignedTo != null ? assignedTo : "Unassigned")
            .category(category != null ? category : "General")
            .dueDate(dueDate)
            .build();

        taskRepo.save(task);
        return task;
    }

    // ── READ ──────────────────────────────────
    public Task getById(String id) {
        return taskRepo.findById(id)
            .orElseThrow(() -> new TaskNotFoundException(id));
    }

    public List<Task> getAllTasks() {
        return taskRepo.findAll();
    }

    public List<Task> getByStatus(Task.Status status) {
        return taskRepo.findByStatus(status);
    }

    public List<Task> getByPriority(Task.Priority priority) {
        return taskRepo.findByPriority(priority);
    }

    public List<Task> getByAssignee(String assignedTo) {
        return taskRepo.findByAssignee(assignedTo);
    }

    public List<Task> getOverdueTasks() {
        return taskRepo.findAll().stream()
            .filter(Task::isOverdue)
            .sorted(Comparator.comparing(Task::getDueDate))
            .collect(Collectors.toList());
    }

    public List<Task> searchByTitle(String keyword) {
        String kw = keyword.toLowerCase().trim();
        return taskRepo.findAll().stream()
            .filter(t -> t.getTitle().toLowerCase().contains(kw)
                      || t.getDescription().toLowerCase().contains(kw))
            .collect(Collectors.toList());
    }

    // ── UPDATE ────────────────────────────────
    public Task updateTitle(String id, String newTitle) {
        ValidationUtil.requireNonEmpty(newTitle, "Title");
        Task task = getById(id);
        task.setTitle(newTitle.trim());
        taskRepo.save(task);
        return task;
    }

    public Task updateStatus(String id, Task.Status status) {
        ValidationUtil.requireNonNull(status, "Status");
        Task task = getById(id);
        task.setStatus(status);
        taskRepo.save(task);
        return task;
    }

    public Task updatePriority(String id, Task.Priority priority) {
        ValidationUtil.requireNonNull(priority, "Priority");
        Task task = getById(id);
        task.setPriority(priority);
        taskRepo.save(task);
        return task;
    }

    public Task updateProgress(String id, int percent) {
        ValidationUtil.requireRange(percent, 0, 100, "Progress");
        Task task = getById(id);
        task.updateProgress(percent);
        taskRepo.save(task);
        return task;
    }

    public Task assignTask(String id, String assignedTo) {
        ValidationUtil.requireNonEmpty(assignedTo, "Assignee");
        Task task = getById(id);
        task.setAssignedTo(assignedTo);
        taskRepo.save(task);
        return task;
    }

    public Task markComplete(String id) {
        Task task = getById(id);
        task.markComplete();
        taskRepo.save(task);
        return task;
    }

    // ── DELETE ────────────────────────────────
    public boolean deleteTask(String id) {
        if (!taskRepo.existsById(id))
            throw new TaskNotFoundException(id);
        commentsMap.remove(id);
        return taskRepo.deleteById(id);
    }

    // ── COMMENTS ──────────────────────────────
    public Comment addComment(String taskId, String authorId, String authorName, String content) {
        ValidationUtil.requireNonEmpty(content, "Comment content");
        if (!taskRepo.existsById(taskId)) throw new TaskNotFoundException(taskId);
        Comment comment = new Comment(taskId, authorId, authorName, content);
        commentsMap.computeIfAbsent(taskId, k -> new ArrayList<>()).add(comment);
        return comment;
    }

    public List<Comment> getComments(String taskId) {
        return commentsMap.getOrDefault(taskId, Collections.emptyList());
    }

    // ── STATISTICS ────────────────────────────
    public Map<String, Object> getStatistics() {
        List<Task> all = taskRepo.findAll();
        Map<String, Object> stats = new LinkedHashMap<>();
        stats.put("Total Tasks",       all.size());
        stats.put("TODO",              all.stream().filter(t -> t.getStatus() == Task.Status.TODO).count());
        stats.put("In Progress",       all.stream().filter(t -> t.getStatus() == Task.Status.IN_PROGRESS).count());
        stats.put("Completed",         all.stream().filter(t -> t.getStatus() == Task.Status.COMPLETED).count());
        stats.put("Overdue",           all.stream().filter(Task::isOverdue).count());
        stats.put("Critical Priority", all.stream().filter(t -> t.getPriority() == Task.Priority.CRITICAL).count());
        double avgProgress = all.isEmpty() ? 0 :
            all.stream().mapToInt(Task::getCompletionPercent).average().orElse(0);
        stats.put("Avg Completion",    String.format("%.1f%%", avgProgress));
        return stats;
    }
}
