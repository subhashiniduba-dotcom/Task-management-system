package com.tms.service;

import com.tms.exception.UserNotFoundException;
import com.tms.exception.ValidationException;
import com.tms.model.User;
import com.tms.repository.UserRepository;
import com.tms.util.ValidationUtil;

import java.util.List;
import java.util.UUID;

/**
 * UserService — business logic for User management.
 * Demonstrates: SRP, Dependency Injection, custom exception handling.
 */
public class UserService {

    private final UserRepository userRepo;

    public UserService(UserRepository userRepo) {
        this.userRepo = userRepo;
    }

    public User createUser(String name, String email, User.Role role) {
        ValidationUtil.requireNonEmpty(name,  "Name");
        ValidationUtil.requireValidEmail(email);

        if (userRepo.findByEmail(email).isPresent())
            throw new ValidationException("Email already registered: " + email);

        String id   = "USR-" + UUID.randomUUID().toString().substring(0, 6).toUpperCase();
        User   user = new User(id, name.trim(), email.trim().toLowerCase(), role);
        userRepo.save(user);
        return user;
    }

    public User getById(String id) {
        return userRepo.findById(id)
            .orElseThrow(() -> new UserNotFoundException(id));
    }

    public List<User> getAllUsers()           { return userRepo.findAll(); }
    public List<User> getUsersByRole(User.Role role) { return userRepo.findByRole(role); }

    public User updateRole(String id, User.Role role) {
        User user = getById(id);
        user.setRole(role);
        userRepo.save(user);
        return user;
    }

    public boolean deactivateUser(String id) {
        User user = getById(id);
        user.setActive(false);
        userRepo.save(user);
        return true;
    }
}
