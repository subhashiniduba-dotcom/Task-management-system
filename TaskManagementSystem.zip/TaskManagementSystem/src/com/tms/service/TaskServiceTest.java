package com.tms.service;

import com.tms.exception.TaskNotFoundException;
import com.tms.exception.ValidationException;
import com.tms.model.Task;
import com.tms.repository.InMemoryTaskRepository;
import org.junit.jupiter.api.*;

import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * TaskServiceTest — unit tests for TaskService.
 * Demonstrates: JUnit 5, Arrange-Act-Assert pattern, test isolation.
 */
@DisplayName("TaskService Unit Tests")
class TaskServiceTest {

    private TaskService  service;
    private Task         sampleTask;

    @BeforeEach
    void setUp() {
        service    = new TaskService(new InMemoryTaskRepository());
        sampleTask = service.createTask(
            "Test Task", "A description",
            Task.Priority.HIGH, "Alice",
            "Backend", LocalDate.now().plusDays(5));
    }

    // ── CREATE ────────────────────────────────
    @Test
    @DisplayName("Create task — valid input — returns task with ID")
    void createTask_validInput_returnsTaskWithId() {
        assertNotNull(sampleTask.getId());
        assertEquals("Test Task",         sampleTask.getTitle());
        assertEquals(Task.Priority.HIGH,  sampleTask.getPriority());
        assertEquals(Task.Status.TODO,    sampleTask.getStatus());
        assertEquals("Alice",             sampleTask.getAssignedTo());
        assertEquals(0,                   sampleTask.getCompletionPercent());
    }

    @Test
    @DisplayName("Create task — empty title — throws ValidationException")
    void createTask_emptyTitle_throwsValidationException() {
        assertThrows(ValidationException.class, () ->
            service.createTask("", "desc", Task.Priority.LOW, "Bob", "Cat", null));
    }

    @Test
    @DisplayName("Create task — null priority — defaults to MEDIUM")
    void createTask_nullPriority_defaultsMedium() {
        Task t = service.createTask("T", "d", null, "Bob", "Cat", null);
        assertEquals(Task.Priority.MEDIUM, t.getPriority());
    }

    // ── READ ──────────────────────────────────
    @Test
    @DisplayName("Get by ID — existing ID — returns task")
    void getById_existingId_returnsTask() {
        Task found = service.getById(sampleTask.getId());
        assertEquals(sampleTask.getId(), found.getId());
    }

    @Test
    @DisplayName("Get by ID — non-existent ID — throws TaskNotFoundException")
    void getById_nonExistentId_throwsTaskNotFoundException() {
        assertThrows(TaskNotFoundException.class, () -> service.getById("INVALID"));
    }

    @Test
    @DisplayName("Get all tasks — returns all created tasks")
    void getAllTasks_returnsList() {
        service.createTask("Task 2", "", null, null, null, null);
        service.createTask("Task 3", "", null, null, null, null);
        assertEquals(3, service.getAllTasks().size());
    }

    // ── UPDATE ────────────────────────────────
    @Test
    @DisplayName("Update progress to 100 — status becomes COMPLETED")
    void updateProgress_100_statusCompleted() {
        service.updateProgress(sampleTask.getId(), 100);
        Task updated = service.getById(sampleTask.getId());
        assertEquals(Task.Status.COMPLETED, updated.getStatus());
        assertEquals(100,                   updated.getCompletionPercent());
    }

    @Test
    @DisplayName("Update progress to 50 — status becomes IN_PROGRESS")
    void updateProgress_50_statusInProgress() {
        service.updateProgress(sampleTask.getId(), 50);
        Task updated = service.getById(sampleTask.getId());
        assertEquals(Task.Status.IN_PROGRESS, updated.getStatus());
    }

    @Test
    @DisplayName("Update progress invalid value — throws ValidationException")
    void updateProgress_invalidValue_throwsValidationException() {
        assertThrows(ValidationException.class, () ->
            service.updateProgress(sampleTask.getId(), 150));
    }

    @Test
    @DisplayName("Mark complete — status COMPLETED, progress 100")
    void markComplete_setsStatusAndProgress() {
        service.markComplete(sampleTask.getId());
        Task t = service.getById(sampleTask.getId());
        assertEquals(Task.Status.COMPLETED, t.getStatus());
        assertEquals(100,                   t.getCompletionPercent());
        assertTrue(t.isCompleted());
    }

    // ── DELETE ────────────────────────────────
    @Test
    @DisplayName("Delete task — existing ID — task no longer found")
    void deleteTask_existingId_removesTask() {
        String id = sampleTask.getId();
        assertTrue(service.deleteTask(id));
        assertThrows(TaskNotFoundException.class, () -> service.getById(id));
    }

    @Test
    @DisplayName("Delete task — non-existent ID — throws TaskNotFoundException")
    void deleteTask_nonExistentId_throwsException() {
        assertThrows(TaskNotFoundException.class, () -> service.deleteTask("FAKE"));
    }

    // ── FILTER ────────────────────────────────
    @Test
    @DisplayName("Filter by status TODO — returns correct tasks")
    void filterByStatus_TODO_returnsCorrectList() {
        service.markComplete(sampleTask.getId());
        service.createTask("Task2", "", null, null, null, null);
        List<Task> todos = service.getByStatus(Task.Status.TODO);
        assertEquals(1, todos.size());
        assertEquals("Task2", todos.get(0).getTitle());
    }

    @Test
    @DisplayName("Search by keyword — returns matching tasks")
    void searchByTitle_matchingKeyword_returnsTasks() {
        service.createTask("Fix login bug", "critical fix", Task.Priority.CRITICAL, null, null, null);
        List<Task> results = service.searchByTitle("login");
        assertEquals(1, results.size());
        assertEquals("Fix login bug", results.get(0).getTitle());
    }

    // ── OVERDUE ───────────────────────────────
    @Test
    @DisplayName("Get overdue tasks — past due date — included in results")
    void getOverdueTasks_pastDueDate_returnsTask() {
        Task overdueTask = service.createTask(
            "Old Task", "", null, null, null,
            LocalDate.now().minusDays(3));
        List<Task> overdue = service.getOverdueTasks();
        assertTrue(overdue.stream().anyMatch(t -> t.getId().equals(overdueTask.getId())));
    }

    @Test
    @DisplayName("Completed task — past due date — NOT overdue")
    void completedTask_pastDueDate_notOverdue() {
        Task old = service.createTask("Done", "", null, null, null, LocalDate.now().minusDays(1));
        service.markComplete(old.getId());
        assertFalse(service.getById(old.getId()).isOverdue());
    }
}
