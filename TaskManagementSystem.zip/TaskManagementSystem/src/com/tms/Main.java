package com.tms;

import com.tms.model.Task;
import com.tms.model.User;
import com.tms.repository.InMemoryTaskRepository;
import com.tms.repository.InMemoryUserRepository;
import com.tms.service.TaskService;
import com.tms.service.UserService;
import com.tms.ui.ConsoleUI;

import java.time.LocalDate;

/**
 * Main — application entry point.
 * Demonstrates: Dependency Injection wiring, modular initialization.
 *
 * Architecture:
 *   Main
 *    └── ConsoleUI          (Presentation Layer)
 *         ├── TaskService   (Business Logic Layer)
 *         │    └── InMemoryTaskRepository  (Data Layer)
 *         └── UserService   (Business Logic Layer)
 *              └── InMemoryUserRepository  (Data Layer)
 */
public class Main {

    public static void main(String[] args) {

        // ── Wire dependencies ──────────────────
        InMemoryTaskRepository taskRepo = new InMemoryTaskRepository();
        InMemoryUserRepository userRepo = new InMemoryUserRepository();

        TaskService taskService = new TaskService(taskRepo);
        UserService userService = new UserService(userRepo);

        // ── Seed demo data ─────────────────────
        seedData(taskService, userService);

        // ── Launch UI ──────────────────────────
        ConsoleUI ui = new ConsoleUI(taskService, userService);
        ui.start();
    }

    private static void seedData(TaskService ts, UserService us) {

        // Seed users
        User alice = us.createUser("Alice Johnson", "alice@tms.dev", User.Role.MANAGER);
        User bob   = us.createUser("Bob Smith",     "bob@tms.dev",   User.Role.DEVELOPER);
        User cara  = us.createUser("Cara Lee",      "cara@tms.dev",  User.Role.TESTER);

        // Seed tasks
        Task t1 = ts.createTask("Design database schema",
            "Create ER diagram and normalized schema for the new module",
            Task.Priority.HIGH, alice.getName(), "Backend",
            LocalDate.now().plusDays(3));

        Task t2 = ts.createTask("Implement login API",
            "JWT-based authentication endpoint",
            Task.Priority.CRITICAL, bob.getName(), "Backend",
            LocalDate.now().plusDays(1));

        Task t3 = ts.createTask("Write unit tests for UserService",
            "Achieve 90% coverage using JUnit 5",
            Task.Priority.MEDIUM, cara.getName(), "Testing",
            LocalDate.now().plusDays(7));

        Task t4 = ts.createTask("Fix CSS layout on mobile",
            "Responsive design broken on screens < 480px",
            Task.Priority.LOW, bob.getName(), "Frontend",
            LocalDate.now().minusDays(2));   // overdue

        Task t5 = ts.createTask("Deploy to staging environment",
            "Set up CI/CD pipeline for staging",
            Task.Priority.HIGH, alice.getName(), "DevOps",
            LocalDate.now().plusDays(5));

        // Seed some progress
        ts.updateProgress(t1.getId(), 60);
        ts.updateProgress(t2.getId(), 30);
        ts.markComplete(t3.getId());
        ts.updateStatus(t5.getId(), Task.Status.IN_PROGRESS);

        // Seed comments
        ts.addComment(t1.getId(), alice.getId(), alice.getName(), "Started ER diagram in Lucidchart.");
        ts.addComment(t2.getId(), bob.getId(),   bob.getName(),   "Using JJWT library for token generation.");
    }
}
