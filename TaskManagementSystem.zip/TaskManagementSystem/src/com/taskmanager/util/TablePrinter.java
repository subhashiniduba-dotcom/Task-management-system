package com.taskmanager.util;

import com.taskmanager.model.Task;
import java.util.List;

/**
 * TablePrinter — utility for formatted console output.
 * Static utility class — no instantiation needed.
 */
public final class TablePrinter {

    private static final String HEADER_FMT = "%-4s  %-30s  %-14s  %-10s  %-10s  %-12s  %s%n";
    private static final String ROW_FMT    = "%-4d  %-30s  %-14s  %-10s  %-10s  %-12s  %s%n";
    private static final String DIVIDER    = "─".repeat(100);

    private TablePrinter() {}

    public static void printTasks(List<Task> tasks) {
        if (tasks.isEmpty()) { System.out.println("  No tasks found."); return; }
        System.out.println(DIVIDER);
        System.out.printf(HEADER_FMT, "ID", "Title", "Status", "Priority", "Category", "Assigned To", "Due Date");
        System.out.println(DIVIDER);
        tasks.forEach(t -> System.out.printf(ROW_FMT,
            t.getId(),
            truncate(t.getTitle(), 30),
            t.getStatus(),
            t.getPriority(),
            t.getCategory(),
            t.getAssignedTo() != null ? t.getAssignedTo() : "—",
            t.getDueDate()    != null ? t.getDueDate().toString() : "—"
        ));
        System.out.println(DIVIDER);
        System.out.printf("  %d task(s) displayed.%n%n", tasks.size());
    }

    public static void printTask(Task t) {
        System.out.println();
        System.out.println("  ┌─ Task Detail " + "─".repeat(50));
        System.out.printf("  │  ID          : %d%n",   t.getId());
        System.out.printf("  │  Title       : %s%n",   t.getTitle());
        System.out.printf("  │  Description : %s%n",   t.getDescription() != null ? t.getDescription() : "—");
        System.out.printf("  │  Status      : %s%n",   t.getStatus());
        System.out.printf("  │  Priority    : %s%n",   t.getPriority());
        System.out.printf("  │  Category    : %s%n",   t.getCategory());
        System.out.printf("  │  Assigned To : %s%n",   t.getAssignedTo() != null ? t.getAssignedTo() : "—");
        System.out.printf("  │  Due Date    : %s%s%n", t.getDueDate() != null ? t.getDueDate() : "—", t.isOverdue() ? "  OVERDUE" : "");
        System.out.printf("  │  Created At  : %s%n",   t.getCreatedAt());
        System.out.printf("  │  Updated At  : %s%n",   t.getUpdatedAt());
        if (t.getCompletedAt() != null)
            System.out.printf("  │  Completed   : %s%n", t.getCompletedAt());
        System.out.println("  └" + "─".repeat(63));
        System.out.println();
    }

    private static String truncate(String s, int max) {
        return s.length() <= max ? s : s.substring(0, max - 3) + "...";
    }
}
