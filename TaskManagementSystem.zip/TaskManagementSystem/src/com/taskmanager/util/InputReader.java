package com.taskmanager.util;

import com.taskmanager.model.*;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.Scanner;

/**
 * InputReader — safe, reusable console input helpers.
 * Wraps Scanner with validation to avoid crashes on bad input.
 */
public class InputReader {

    private final Scanner scanner;

    public InputReader(Scanner scanner) { this.scanner = scanner; }

    public String readLine(String prompt) {
        System.out.print(prompt);
        return scanner.nextLine().trim();
    }

    public int readInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            String line = scanner.nextLine().trim();
            try   { return Integer.parseInt(line); }
            catch (NumberFormatException e) { System.out.println("  Please enter a valid number."); }
        }
    }

    public Priority readPriority() {
        System.out.println("  Priorities: 1=Low  2=Medium  3=High  4=Critical");
        while (true) {
            int choice = readInt("  Choice: ");
            switch (choice) {
                case 1: return Priority.LOW;
                case 2: return Priority.MEDIUM;
                case 3: return Priority.HIGH;
                case 4: return Priority.CRITICAL;
                default: System.out.println("  Enter 1-4.");
            }
        }
    }

    public Category readCategory() {
        Category[] cats = Category.values();
        for (int i = 0; i < cats.length; i++)
            System.out.printf("  %d=%s  ", i + 1, cats[i].getLabel());
        System.out.println();
        while (true) {
            int choice = readInt("  Choice: ");
            if (choice >= 1 && choice <= cats.length) return cats[choice - 1];
            System.out.println("  Enter 1-" + cats.length + ".");
        }
    }

    public LocalDate readDateOptional(String prompt) {
        System.out.print(prompt + " (yyyy-mm-dd, or blank to skip): ");
        String line = scanner.nextLine().trim();
        if (line.isEmpty()) return null;
        try   { return LocalDate.parse(line); }
        catch (DateTimeParseException e) { System.out.println("  Invalid date — skipped."); return null; }
    }
}
