package com.taskmanager.service;

/**
 * TaskStats — value object holding dashboard statistics.
 * Immutable — all fields set via constructor.
 */
public class TaskStats {

    private final int total;
    private final int todo;
    private final int inProgress;
    private final int done;
    private final int overdue;
    private final int critical;

    public TaskStats(int total, int todo, int inProgress, int done, int overdue, int critical) {
        this.total      = total;
        this.todo       = todo;
        this.inProgress = inProgress;
        this.done       = done;
        this.overdue    = overdue;
        this.critical   = critical;
    }

    public int getTotal()      { return total; }
    public int getTodo()       { return todo; }
    public int getInProgress() { return inProgress; }
    public int getDone()       { return done; }
    public int getOverdue()    { return overdue; }
    public int getCritical()   { return critical; }

    public double getCompletionRate() {
        return total == 0 ? 0.0 : (done * 100.0 / total);
    }

    @Override
    public String toString() {
        return String.format(
            "Total: %d | To Do: %d | In Progress: %d | Done: %d | Overdue: %d | Critical: %d | Completion: %.1f%%",
            total, todo, inProgress, done, overdue, critical, getCompletionRate());
    }
}
