package com.taskmanager.service;

import com.taskmanager.model.*;
import java.time.LocalDate;
import java.util.List;

/**
 * TaskService — Business Logic interface.
 *
 * OOP Principle: Abstraction + Separation of Concerns.
 * All business rules live here, completely separated from
 * storage (Repository) and presentation (UI).
 */
public interface TaskService {

    Task       createTask(String title, Priority priority, Category category);
    Task       getTask(int id);
    List<Task> getAllTasks();
    List<Task> getTasksByStatus(Status status);
    List<Task> getTasksByPriority(Priority priority);
    List<Task> getTasksByCategory(Category category);
    List<Task> getOverdueTasks();
    List<Task> searchTasks(String keyword);

    void       updateTitle(int id, String title);
    void       updateDescription(int id, String description);
    void       updatePriority(int id, Priority priority);
    void       updateCategory(int id, Category category);
    void       assignTask(int id, String assignee);
    void       setDueDate(int id, LocalDate date);

    void       startTask(int id);
    void       completeTask(int id);
    void       reopenTask(int id);
    void       deleteTask(int id);

    TaskStats  getStats();
}
