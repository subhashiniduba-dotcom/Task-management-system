package com.taskmanager.service;

import com.taskmanager.exception.TaskNotFoundException;
import com.taskmanager.model.*;
import com.taskmanager.repository.TaskRepository;

import java.time.LocalDate;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

/**
 * TaskServiceImpl — concrete service with all business logic.
 *
 * OOP Principles:
 *  Single Responsibility : only business logic, no storage, no UI
 *  Dependency Injection  : repository injected via constructor
 *  Open/Closed           : open for extension (subclass), closed for modification
 */
public class TaskServiceImpl implements TaskService {

    private final TaskRepository    repository;
    private final AtomicInteger     idGenerator = new AtomicInteger(1);

    /** Constructor Injection — decouples service from any specific repository. */
    public TaskServiceImpl(TaskRepository repository) {
        this.repository = repository;
    }

    @Override
    public Task createTask(String title, Priority priority, Category category) {
        int  id   = idGenerator.getAndIncrement();
        Task task = new Task(id, title, priority, category);
        repository.save(task);
        return task;
    }

    @Override
    public Task getTask(int id) {
        return repository.findById(id)
            .orElseThrow(() -> new TaskNotFoundException(id));
    }

    @Override public List<Task> getAllTasks()                    { return repository.findAll(); }
    @Override public List<Task> getTasksByStatus(Status s)      { return repository.findByStatus(s); }
    @Override public List<Task> getTasksByPriority(Priority p)  { return repository.findByPriority(p); }
    @Override public List<Task> getTasksByCategory(Category c)  { return repository.findByCategory(c); }
    @Override public List<Task> getOverdueTasks()               { return repository.findOverdue(); }

    @Override
    public List<Task> searchTasks(String keyword) {
        String kw = keyword.toLowerCase().trim();
        return repository.findAll().stream()
            .filter(t -> t.getTitle().toLowerCase().contains(kw)
                      || (t.getDescription() != null && t.getDescription().toLowerCase().contains(kw))
                      || (t.getAssignedTo() != null && t.getAssignedTo().toLowerCase().contains(kw)))
            .collect(Collectors.toList());
    }

    @Override public void updateTitle(int id, String title)         { getTask(id).setTitle(title); }
    @Override public void updateDescription(int id, String desc)    { getTask(id).setDescription(desc); }
    @Override public void updatePriority(int id, Priority p)        { getTask(id).setPriority(p); }
    @Override public void updateCategory(int id, Category c)        { getTask(id).setCategory(c); }
    @Override public void assignTask(int id, String assignee)       { getTask(id).setAssignedTo(assignee); }
    @Override public void setDueDate(int id, LocalDate date)        { getTask(id).setDueDate(date); }

    @Override public void startTask(int id)    { getTask(id).markInProgress(); }
    @Override public void completeTask(int id) { getTask(id).markDone(); }
    @Override public void reopenTask(int id)   { getTask(id).markTodo(); }
    @Override public void deleteTask(int id)   { repository.delete(id); }

    @Override
    public TaskStats getStats() {
        List<Task> all = repository.findAll();
        return new TaskStats(
            all.size(),
            (int) all.stream().filter(Task::isTodo).count(),
            (int) all.stream().filter(Task::isInProgress).count(),
            (int) all.stream().filter(Task::isDone).count(),
            (int) all.stream().filter(Task::isOverdue).count(),
            (int) all.stream().filter(t -> t.getPriority() == Priority.CRITICAL).count()
        );
    }
}
