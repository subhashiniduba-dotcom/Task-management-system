package com.taskmanager.test;

import com.taskmanager.exception.TaskNotFoundException;
import com.taskmanager.model.*;
import com.taskmanager.repository.InMemoryTaskRepository;
import com.taskmanager.service.*;

import java.time.LocalDate;

/**
 * TaskServiceTest — manual unit tests (no JUnit dependency required).
 * Run with: java com.taskmanager.test.TaskServiceTest
 *
 * Each test prints PASS or FAIL.
 */
public class TaskServiceTest {

    private static int passed = 0;
    private static int failed = 0;

    public static void main(String[] args) {
        System.out.println("Running TaskService Tests...");
        System.out.println("─".repeat(50));

        testCreateTask();
        testGetTask();
        testGetTaskNotFound();
        testStartTask();
        testCompleteTask();
        testReopenTask();
        testDeleteTask();
        testSearchTasks();
        testOverdueTask();
        testStats();

        System.out.println("─".repeat(50));
        System.out.printf("Results: %d PASSED, %d FAILED%n", passed, failed);
    }

    // ── Helpers ───────────────────────────────
    private static TaskService newService() {
        return new TaskServiceImpl(new InMemoryTaskRepository());
    }

    private static void assertTrue(String name, boolean condition) {
        if (condition) { System.out.println("  PASS: " + name); passed++; }
        else           { System.out.println("  FAIL: " + name); failed++; }
    }

    // ── Tests ─────────────────────────────────
    private static void testCreateTask() {
        TaskService svc = newService();
        Task t = svc.createTask("Test task", Priority.HIGH, Category.WORK);
        assertTrue("createTask — returns non-null",     t != null);
        assertTrue("createTask — correct title",        "Test task".equals(t.getTitle()));
        assertTrue("createTask — status is TODO",       t.getStatus() == Status.TODO);
        assertTrue("createTask — priority is HIGH",     t.getPriority() == Priority.HIGH);
    }

    private static void testGetTask() {
        TaskService svc = newService();
        Task t = svc.createTask("Get test", Priority.LOW, Category.GENERAL);
        Task found = svc.getTask(t.getId());
        assertTrue("getTask — found by ID",             found != null);
        assertTrue("getTask — same ID",                 found.getId() == t.getId());
    }

    private static void testGetTaskNotFound() {
        TaskService svc = newService();
        try { svc.getTask(999); assertTrue("getTask — not found throws exception", false); }
        catch (TaskNotFoundException e) { assertTrue("getTask — not found throws exception", true); }
    }

    private static void testStartTask() {
        TaskService svc = newService();
        Task t = svc.createTask("Start test", Priority.MEDIUM, Category.WORK);
        svc.startTask(t.getId());
        assertTrue("startTask — status is IN_PROGRESS",  t.getStatus() == Status.IN_PROGRESS);
    }

    private static void testCompleteTask() {
        TaskService svc = newService();
        Task t = svc.createTask("Complete test", Priority.MEDIUM, Category.WORK);
        svc.completeTask(t.getId());
        assertTrue("completeTask — status is DONE",       t.getStatus() == Status.DONE);
        assertTrue("completeTask — completedAt set",      t.getCompletedAt() != null);
    }

    private static void testReopenTask() {
        TaskService svc = newService();
        Task t = svc.createTask("Reopen test", Priority.MEDIUM, Category.WORK);
        svc.completeTask(t.getId());
        svc.reopenTask(t.getId());
        assertTrue("reopenTask — status is TODO",         t.getStatus() == Status.TODO);
    }

    private static void testDeleteTask() {
        TaskService svc = newService();
        Task t = svc.createTask("Delete test", Priority.LOW, Category.GENERAL);
        int id = t.getId();
        svc.deleteTask(id);
        try { svc.getTask(id); assertTrue("deleteTask — throws after delete", false); }
        catch (TaskNotFoundException e) { assertTrue("deleteTask — throws after delete", true); }
    }

    private static void testSearchTasks() {
        TaskService svc = newService();
        svc.createTask("Fix payment bug", Priority.CRITICAL, Category.BUG_FIX);
        svc.createTask("Add login feature", Priority.HIGH, Category.FEATURE);
        svc.createTask("Write docs", Priority.LOW, Category.GENERAL);
        assertTrue("searchTasks — finds by keyword",  svc.searchTasks("bug").size() == 1);
        assertTrue("searchTasks — no match returns empty", svc.searchTasks("xyz").isEmpty());
    }

    private static void testOverdueTask() {
        TaskService svc = newService();
        Task t = svc.createTask("Overdue task", Priority.HIGH, Category.WORK);
        svc.setDueDate(t.getId(), LocalDate.now().minusDays(2));
        assertTrue("overdueTask — isOverdue returns true", t.isOverdue());
        svc.completeTask(t.getId());
        assertTrue("overdueTask — done task not overdue",  !t.isOverdue());
    }

    private static void testStats() {
        TaskService svc = newService();
        Task t1 = svc.createTask("Task 1", Priority.HIGH,   Category.WORK);
        Task t2 = svc.createTask("Task 2", Priority.MEDIUM, Category.WORK);
        svc.completeTask(t1.getId());
        TaskStats s = svc.getStats();
        assertTrue("stats — total is 2",        s.getTotal() == 2);
        assertTrue("stats — done is 1",         s.getDone()  == 1);
        assertTrue("stats — todo is 1",         s.getTodo()  == 1);
        assertTrue("stats — completion is 50%", s.getCompletionRate() == 50.0);
    }
}
