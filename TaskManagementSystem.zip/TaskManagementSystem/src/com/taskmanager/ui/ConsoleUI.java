package com.taskmanager.ui;

import com.taskmanager.exception.TaskNotFoundException;
import com.taskmanager.model.*;
import com.taskmanager.service.*;
import com.taskmanager.util.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

/**
 * ConsoleUI — Presentation layer.
 *
 * OOP Principle: Separation of Concerns
 * UI knows nothing about storage or business rules —
 * it only calls TaskService methods and renders results.
 */
public class ConsoleUI {

    private final TaskService service;
    private final InputReader input;
    private       boolean     running = true;

    private static final String DIVIDER = "═".repeat(60);
    private static final String THIN    = "─".repeat(60);

    public ConsoleUI(TaskService service) {
        this.service = service;
        this.input   = new InputReader(new Scanner(System.in));
    }

    // ── Entry point ───────────────────────────
    public void start() {
        printBanner();
        seedDemoData();

        while (running) {
            printMenu();
            int choice = input.readInt("  > ");
            System.out.println();
            handleChoice(choice);
        }
        System.out.println("  Goodbye! Stay organized. 👋");
    }

    // ── Main menu ─────────────────────────────
    private void printMenu() {
        System.out.println();
        System.out.println("  " + THIN);
        System.out.println("  MAIN MENU");
        System.out.println("  " + THIN);
        System.out.println("  1.  View all tasks");
        System.out.println("  2.  Add new task");
        System.out.println("  3.  View task detail");
        System.out.println("  4.  Update task");
        System.out.println("  5.  Start task (→ In Progress)");
        System.out.println("  6.  Complete task (→ Done)");
        System.out.println("  7.  Reopen task (→ To Do)");
        System.out.println("  8.  Delete task");
        System.out.println("  9.  Filter tasks");
        System.out.println("  10. Search tasks");
        System.out.println("  11. View overdue tasks");
        System.out.println("  12. Dashboard stats");
        System.out.println("  0.  Exit");
        System.out.println("  " + THIN);
    }

    private void handleChoice(int choice) {
        try {
            switch (choice) {
                case 1:  viewAll();         break;
                case 2:  addTask();         break;
                case 3:  viewDetail();      break;
                case 4:  updateTask();      break;
                case 5:  startTask();       break;
                case 6:  completeTask();    break;
                case 7:  reopenTask();      break;
                case 8:  deleteTask();      break;
                case 9:  filterTasks();     break;
                case 10: searchTasks();     break;
                case 11: overdueTask();     break;
                case 12: showStats();       break;
                case 0:  running = false;   break;
                default: System.out.println("  Invalid choice. Enter 0-12.");
            }
        } catch (TaskNotFoundException e) {
            System.out.println("  ERROR: " + e.getMessage());
        } catch (IllegalArgumentException | IllegalStateException e) {
            System.out.println("  ERROR: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("  Unexpected error: " + e.getMessage());
        }
    }

    // ── Actions ───────────────────────────────
    private void viewAll() {
        System.out.println("  ALL TASKS");
        TablePrinter.printTasks(service.getAllTasks());
    }

    private void addTask() {
        System.out.println("  ADD NEW TASK");
        System.out.println("  " + THIN);
        String title = input.readLine("  Title       : ");
        if (title.isEmpty()) { System.out.println("  Title required."); return; }

        System.out.println("  Priority:");
        Priority priority = input.readPriority();
        System.out.println("  Category:");
        Category category = input.readCategory();

        Task task = service.createTask(title, priority, category);

        String desc = input.readLine("  Description : ");
        if (!desc.isEmpty()) service.updateDescription(task.getId(), desc);

        String assignee = input.readLine("  Assign to   : ");
        if (!assignee.isEmpty()) service.assignTask(task.getId(), assignee);

        LocalDate due = input.readDateOptional("  Due date");
        if (due != null) service.setDueDate(task.getId(), due);

        System.out.printf("%n  Task #%d created: "%s"%n", task.getId(), task.getTitle());
    }

    private void viewDetail() {
        int id = input.readInt("  Task ID: ");
        TablePrinter.printTask(service.getTask(id));
    }

    private void updateTask() {
        int id = input.readInt("  Task ID to update: ");
        Task task = service.getTask(id);
        System.out.printf("  Updating: %s%n", task.getTitle());
        System.out.println("  1=Title  2=Description  3=Priority  4=Category  5=Assignee  6=Due Date");
        int field = input.readInt("  Field: ");
        switch (field) {
            case 1: service.updateTitle(id, input.readLine("  New title: ")); break;
            case 2: service.updateDescription(id, input.readLine("  New description: ")); break;
            case 3: service.updatePriority(id, input.readPriority()); break;
            case 4: service.updateCategory(id, input.readCategory()); break;
            case 5: service.assignTask(id, input.readLine("  Assignee: ")); break;
            case 6: service.setDueDate(id, input.readDateOptional("  Due date")); break;
            default: System.out.println("  Invalid field."); return;
        }
        System.out.println("  Task updated.");
    }

    private void startTask()    { int id = input.readInt("  Task ID: "); service.startTask(id);    System.out.println("  Task started."); }
    private void completeTask() { int id = input.readInt("  Task ID: "); service.completeTask(id); System.out.println("  Task completed."); }
    private void reopenTask()   { int id = input.readInt("  Task ID: "); service.reopenTask(id);   System.out.println("  Task reopened."); }

    private void deleteTask() {
        int id = input.readInt("  Task ID: ");
        String confirm = input.readLine("  Delete task #" + id + "? (yes/no): ");
        if ("yes".equalsIgnoreCase(confirm)) {
            service.deleteTask(id);
            System.out.println("  Task deleted.");
        } else {
            System.out.println("  Cancelled.");
        }
    }

    private void filterTasks() {
        System.out.println("  FILTER BY: 1=Status  2=Priority  3=Category");
        int choice = input.readInt("  Choice: ");
        List<Task> result;
        switch (choice) {
            case 1:
                System.out.println("  1=To Do  2=In Progress  3=Done");
                int sc = input.readInt("  Status: ");
                Status[] statuses = Status.values();
                result = service.getTasksByStatus(statuses[Math.min(sc - 1, statuses.length - 1)]);
                break;
            case 2:
                result = service.getTasksByPriority(input.readPriority());
                break;
            case 3:
                result = service.getTasksByCategory(input.readCategory());
                break;
            default: System.out.println("  Invalid."); return;
        }
        TablePrinter.printTasks(result);
    }

    private void searchTasks() {
        String kw = input.readLine("  Search keyword: ");
        TablePrinter.printTasks(service.searchTasks(kw));
    }

    private void overdueTask() {
        System.out.println("  OVERDUE TASKS");
        TablePrinter.printTasks(service.getOverdueTasks());
    }

    private void showStats() {
        TaskStats s = service.getStats();
        System.out.println();
        System.out.println("  " + DIVIDER);
        System.out.println("  DASHBOARD");
        System.out.println("  " + DIVIDER);
        System.out.printf("  Total Tasks   : %d%n",       s.getTotal());
        System.out.printf("  To Do         : %d%n",       s.getTodo());
        System.out.printf("  In Progress   : %d%n",       s.getInProgress());
        System.out.printf("  Done          : %d%n",       s.getDone());
        System.out.printf("  Overdue       : %d%n",       s.getOverdue());
        System.out.printf("  Critical      : %d%n",       s.getCritical());
        System.out.printf("  Completion    : %.1f%%%n",   s.getCompletionRate());
        System.out.println("  " + DIVIDER);
        System.out.println();
    }

    // ── Banner & Seed ─────────────────────────
    private void printBanner() {
        System.out.println();
        System.out.println("  " + DIVIDER);
        System.out.println("       TASK MANAGEMENT SYSTEM");
        System.out.println("       OOP Design with Java");
        System.out.println("  " + DIVIDER);
        System.out.println();
    }

    private void seedDemoData() {
        Task t1 = service.createTask("Design database schema", Priority.HIGH, Category.WORK);
        service.updateDescription(t1.getId(), "ERD for user and order tables");
        service.assignTask(t1.getId(), "Subhashini");
        service.setDueDate(t1.getId(), LocalDate.now().plusDays(3));
        service.startTask(t1.getId());

        Task t2 = service.createTask("Fix login bug", Priority.CRITICAL, Category.BUG_FIX);
        service.assignTask(t2.getId(), "Ravi");
        service.setDueDate(t2.getId(), LocalDate.now().plusDays(1));

        Task t3 = service.createTask("Write unit tests", Priority.MEDIUM, Category.WORK);
        service.setDueDate(t3.getId(), LocalDate.now().plusDays(7));

        Task t4 = service.createTask("Daily exercise routine", Priority.MEDIUM, Category.HEALTH);
        service.assignTask(t4.getId(), "Subhashini");
        service.completeTask(t4.getId());

        Task t5 = service.createTask("Study DSA Chapter 5", Priority.HIGH, Category.STUDY);
        service.setDueDate(t5.getId(), LocalDate.now().plusDays(2));

        System.out.println("  5 demo tasks loaded.");
    }
}
