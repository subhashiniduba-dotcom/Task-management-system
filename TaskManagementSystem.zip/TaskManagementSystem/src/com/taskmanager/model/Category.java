package com.taskmanager.model;

/** Domain category for grouping tasks. */
public enum Category {
    GENERAL("General"),
    WORK("Work"),
    PERSONAL("Personal"),
    STUDY("Study"),
    HEALTH("Health"),
    FINANCE("Finance"),
    BUG_FIX("Bug Fix"),
    FEATURE("Feature");

    private final String label;
    Category(String label) { this.label = label; }
    public String getLabel() { return label; }
    @Override public String toString() { return label; }
}
