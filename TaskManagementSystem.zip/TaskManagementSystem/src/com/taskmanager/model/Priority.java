package com.taskmanager.model;

/** Task urgency levels — used for sorting and filtering. */
public enum Priority {
    LOW("Low", 1),
    MEDIUM("Medium", 2),
    HIGH("High", 3),
    CRITICAL("Critical", 4);

    private final String label;
    private final int    rank;

    Priority(String label, int rank) { this.label = label; this.rank = rank; }

    public String getLabel() { return label; }
    public int    getRank()  { return rank; }

    @Override public String toString() { return label; }
}
