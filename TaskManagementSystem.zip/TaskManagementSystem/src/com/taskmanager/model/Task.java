package com.taskmanager.model;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Objects;

/**
 * Task — core domain entity.
 *
 * OOP Principles applied:
 *  Encapsulation  : all fields private, accessed via getters/setters
 *  Immutability   : id and createdAt are final and set once
 *  Validation     : setters enforce business rules before assigning
 */
public class Task {

    private final int           id;
    private       String        title;
    private       String        description;
    private       Priority      priority;
    private       Category      category;
    private       Status        status;
    private       String        assignedTo;
    private       LocalDate     dueDate;
    private final LocalDateTime createdAt;
    private       LocalDateTime updatedAt;
    private       LocalDateTime completedAt;

    public Task(int id, String title, Priority priority, Category category) {
        if (title == null || title.trim().isEmpty())
            throw new IllegalArgumentException("Task title cannot be empty.");
        this.id        = id;
        this.title     = title.trim();
        this.priority  = priority != null ? priority : Priority.MEDIUM;
        this.category  = category != null ? category : Category.GENERAL;
        this.status    = Status.TODO;
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
    }

    // ── Status transitions ────────────────────
    public void markInProgress() {
        if (this.status == Status.DONE)
            throw new IllegalStateException("Cannot reopen a completed task.");
        this.status    = Status.IN_PROGRESS;
        this.updatedAt = LocalDateTime.now();
    }

    public void markDone() {
        this.status      = Status.DONE;
        this.completedAt = LocalDateTime.now();
        this.updatedAt   = LocalDateTime.now();
    }

    public void markTodo() {
        this.status    = Status.TODO;
        this.updatedAt = LocalDateTime.now();
    }

    // ── Computed helpers ──────────────────────
    public boolean isOverdue() {
        return dueDate != null && status != Status.DONE && dueDate.isBefore(LocalDate.now());
    }
    public boolean isDone()       { return status == Status.DONE; }
    public boolean isInProgress() { return status == Status.IN_PROGRESS; }
    public boolean isTodo()       { return status == Status.TODO; }

    // ── Getters ───────────────────────────────
    public int           getId()          { return id; }
    public String        getTitle()       { return title; }
    public String        getDescription() { return description; }
    public Priority      getPriority()    { return priority; }
    public Category      getCategory()    { return category; }
    public Status        getStatus()      { return status; }
    public String        getAssignedTo()  { return assignedTo; }
    public LocalDate     getDueDate()     { return dueDate; }
    public LocalDateTime getCreatedAt()   { return createdAt; }
    public LocalDateTime getUpdatedAt()   { return updatedAt; }
    public LocalDateTime getCompletedAt() { return completedAt; }

    // ── Setters (validated) ───────────────────
    public void setTitle(String title) {
        if (title == null || title.trim().isEmpty())
            throw new IllegalArgumentException("Title cannot be empty.");
        this.title     = title.trim();
        this.updatedAt = LocalDateTime.now();
    }
    public void setDescription(String d)   { this.description = d; this.updatedAt = LocalDateTime.now(); }
    public void setPriority(Priority p)    { this.priority  = Objects.requireNonNull(p); this.updatedAt = LocalDateTime.now(); }
    public void setCategory(Category c)    { this.category  = Objects.requireNonNull(c); this.updatedAt = LocalDateTime.now(); }
    public void setAssignedTo(String name) { this.assignedTo = name; this.updatedAt = LocalDateTime.now(); }
    public void setDueDate(LocalDate d)    { this.dueDate   = d; this.updatedAt = LocalDateTime.now(); }

    @Override public boolean equals(Object o) { if (this == o) return true; if (!(o instanceof Task)) return false; return id == ((Task)o).id; }
    @Override public int hashCode() { return Integer.hashCode(id); }
    @Override public String toString() {
        return String.format("[#%d] %-30s | %-12s | %-8s | %-10s%s",
            id, title, status, priority, category, isOverdue() ? " OVERDUE" : "");
    }
}
