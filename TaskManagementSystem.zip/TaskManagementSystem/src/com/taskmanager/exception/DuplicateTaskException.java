package com.taskmanager.exception;

/** Thrown when trying to add a task with an ID that already exists. */
public class DuplicateTaskException extends RuntimeException {
    public DuplicateTaskException(int id) {
        super("Task with ID " + id + " already exists.");
    }
}
