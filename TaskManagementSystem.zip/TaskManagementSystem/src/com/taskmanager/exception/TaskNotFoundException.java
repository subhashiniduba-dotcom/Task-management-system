package com.taskmanager.exception;

/** Thrown when a task with the requested ID does not exist in the repository. */
public class TaskNotFoundException extends RuntimeException {
    private final int taskId;

    public TaskNotFoundException(int taskId) {
        super("Task not found with ID: " + taskId);
        this.taskId = taskId;
    }

    public int getTaskId() { return taskId; }
}
