package com.taskmanager;

import com.taskmanager.repository.InMemoryTaskRepository;
import com.taskmanager.repository.TaskRepository;
import com.taskmanager.service.TaskService;
import com.taskmanager.service.TaskServiceImpl;
import com.taskmanager.ui.ConsoleUI;

/**
 * Main — application entry point.
 *
 * Wires the three tiers together via Dependency Injection:
 *   Repository  →  Service  →  UI
 *
 * To swap storage: just change InMemoryTaskRepository to
 * FileTaskRepository or DatabaseTaskRepository — nothing else changes.
 */
public class Main {
    public static void main(String[] args) {
        TaskRepository repository = new InMemoryTaskRepository();
        TaskService    service    = new TaskServiceImpl(repository);
        ConsoleUI      ui         = new ConsoleUI(service);
        ui.start();
    }
}
