package com.taskmanager.repository;

import com.taskmanager.model.*;
import java.util.List;
import java.util.Optional;

/**
 * TaskRepository — Data Access interface.
 *
 * OOP Principle: Abstraction — consumers depend on this interface,
 * not on any specific storage implementation.
 * This makes it trivial to swap InMemoryTaskRepository for a
 * DatabaseTaskRepository or FileTaskRepository without changing
 * any business logic.
 */
public interface TaskRepository {

    void           save(Task task);
    Optional<Task> findById(int id);
    List<Task>     findAll();
    List<Task>     findByStatus(Status status);
    List<Task>     findByPriority(Priority priority);
    List<Task>     findByCategory(Category category);
    List<Task>     findByAssignee(String assignee);
    List<Task>     findOverdue();
    boolean        existsById(int id);
    void           delete(int id);
    int            count();
    int            countByStatus(Status status);
}
