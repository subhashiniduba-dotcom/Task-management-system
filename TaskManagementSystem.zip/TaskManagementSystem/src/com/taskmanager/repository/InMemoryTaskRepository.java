package com.taskmanager.repository;

import com.taskmanager.exception.DuplicateTaskException;
import com.taskmanager.exception.TaskNotFoundException;
import com.taskmanager.model.*;

import java.util.*;
import java.util.stream.Collectors;

/**
 * InMemoryTaskRepository — concrete repository using a HashMap.
 *
 * OOP Principles:
 *  Polymorphism   : implements TaskRepository interface
 *  Encapsulation  : internal storage is private and never exposed
 *
 * Replace with FileTaskRepository or DatabaseTaskRepository
 * without touching any service or UI code.
 */
public class InMemoryTaskRepository implements TaskRepository {

    private final Map<Integer, Task> store = new LinkedHashMap<>();

    @Override
    public void save(Task task) {
        Objects.requireNonNull(task, "Task cannot be null.");
        if (store.containsKey(task.getId()))
            throw new DuplicateTaskException(task.getId());
        store.put(task.getId(), task);
    }

    @Override
    public Optional<Task> findById(int id) {
        return Optional.ofNullable(store.get(id));
    }

    @Override
    public List<Task> findAll() {
        return new ArrayList<>(store.values());
    }

    @Override
    public List<Task> findByStatus(Status status) {
        return store.values().stream()
            .filter(t -> t.getStatus() == status)
            .collect(Collectors.toList());
    }

    @Override
    public List<Task> findByPriority(Priority priority) {
        return store.values().stream()
            .filter(t -> t.getPriority() == priority)
            .collect(Collectors.toList());
    }

    @Override
    public List<Task> findByCategory(Category category) {
        return store.values().stream()
            .filter(t -> t.getCategory() == category)
            .collect(Collectors.toList());
    }

    @Override
    public List<Task> findByAssignee(String assignee) {
        return store.values().stream()
            .filter(t -> assignee.equalsIgnoreCase(t.getAssignedTo()))
            .collect(Collectors.toList());
    }

    @Override
    public List<Task> findOverdue() {
        return store.values().stream()
            .filter(Task::isOverdue)
            .collect(Collectors.toList());
    }

    @Override
    public boolean existsById(int id) { return store.containsKey(id); }

    @Override
    public void delete(int id) {
        if (!store.containsKey(id)) throw new TaskNotFoundException(id);
        store.remove(id);
    }

    @Override
    public int count()                    { return store.size(); }

    @Override
    public int countByStatus(Status s)    {
        return (int) store.values().stream().filter(t -> t.getStatus() == s).count();
    }
}
